# Query-Sample Sensitivity and Cross-Lingual Rank Transfer in Pairwise LLM-as-a-Judge Evaluation (MIRAGE-Bench)

**Author:** Devarasetty Seetesh (`MRA2026015`)  
**Institution:** Department of Information Technology, Indian Institute of Information Technology-Allahabad  

## Research Questions
1. **RQ1 (Baseline Hierarchy):** What is the baseline win-rate ranking of 19 evaluated LLMs on the English MIRAGE-Bench development partition (`en`, `dev`) when ties receive half-credit (`0.5`)?
2. **RQ2 (Query-Sample Sensitivity):** How rapidly does overall rank agreement (Kendall's $\tau_b$ and Spearman's $\rho$) converge across query sample fractions (`25%`, `50%`, `75%`, `100%`) over `100` repeated random subsamples, and which model tiers experience the greatest rank volatility?
3. **RQ3 (Cross-Lingual Rank Consistency):** To what extent do pairwise model rankings correlate across all `18` languages in MIRAGE-Bench?

## Repository Structure
```text
AITR_Lab02_MRA2026015_MIRAGE_Ranking_Stability/
├── README.md                      # Research question, setup, and reproduction instructions
├── requirements.txt               # Verified Python dependencies
├── configs/
│   └── experiment_config.yaml     # Frozen experimental settings and random seeds
├── data/
│   └── README.md                  # Dataset source, schema, access, and filtering protocol
├── notebooks/
│   └── MIRAGE_Bench_Experiments.ipynb  # Complete runnable Jupyter/Colab notebook
├── src/
│   └── ranking_utils.py           # Reusable pairwise ranking, subsampling, and correlation modules
├── scripts/
│   └── run_experiments.py         # End-to-end CLI entrypoint to regenerate tables and figures
├── results/
│   ├── tables/                    # Genuine metric CSV tables (model_ranking.csv, stability_summary.csv, etc.)
│   └── figures/                   # Generated PNG plots (fig1_workflow_pipeline.png, fig2_ranking_stability.png)
├── paper/
│   ├── main.tex                   # Complete ACM-formatted LaTeX manuscript
│   ├── references.bib             # Verified BibTeX bibliography
│   ├── fig1_workflow_pipeline.png # Workflow diagram
│   └── fig2_ranking_stability.png # Stability plot
├── research_decisions.md          # Literature-to-experiment decisions & Gate G1 brief
├── baseline_validation.md         # Reproduction checks, bug fixes, and Gate G2 validation report
└── ai_assistance_log.md           # Significant prompts, debugging fixes, and human verification audit
```

## Setup & Reproduction Instructions
1. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
2. **Run via CLI Script:**
   ```bash
   python scripts/run_experiments.py --config configs/experiment_config.yaml --output_dir results
   ```
   Or open and run `notebooks/MIRAGE_Bench_Experiments.ipynb` in Jupyter / Google Colab.
3. **Dataset Access:** All 18 language splits of `nthakur/mirage-bench-pairwise-judgments` are fetched automatically via Hugging Face `datasets` with fixed random seeds (`42` and `123`).

## Summary of Verified Results
- **English Baseline (`en`, 100 queries, 17,097 judgments):** `gpt-4o-azure` (`0.8533`) and `gpt-4-azure` (`0.8419`) rank #1 and #2, followed by `meta-llama/Meta-Llama-3-70B-Instruct` (`0.7017`).
- **Query-Sample Stability ($R=100$ repeats):** Mean Kendall's $\tau_b$ rises from `0.8552 ± 0.0492` (`25%` queries) to `0.9174 ± 0.0315` (`50%`) and `0.9516 ± 0.0210` (`75%`). Top- and bottom-tier anchor models lock at `SD = 0.00` by `75%` queries, whereas mid-tier open-weight models (`Mistral-7B-Instruct-v0.2`, `SD = 1.45` at `75%`) continue to swap ranks.
- **Cross-Lingual Transfer (18 languages, 153 pairs):** Mean Kendall's $\tau_b = 0.6921 ± 0.1121$ (Spearman's $\rho = 0.8366 ± 0.0947$), ranging from `1.0000` (`ja`–`ko`) down to `0.3450` (`de`–`te`) and `0.3801` (`en`–`te`).
